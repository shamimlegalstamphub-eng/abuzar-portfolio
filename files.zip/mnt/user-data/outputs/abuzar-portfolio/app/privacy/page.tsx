'use client';

import Link from 'next/link';
import { motion } from 'framer-motion';

export default function PrivacyPage() {
  return (
    <main className="min-h-screen bg-dark-950 pt-24 pb-16 px-4 md:px-6">
      <motion.div
        className="max-w-4xl mx-auto"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <Link href="/" className="text-accent hover:text-cyan-300 mb-8 inline-flex items-center gap-2">
          ← Back to Home
        </Link>

        <h1 className="text-5xl font-bold mb-8">Privacy Policy</h1>

        <div className="prose prose-invert max-w-none space-y-6 text-dark-300">
          <section>
            <h2 className="text-2xl font-bold text-white mt-8 mb-4">1. Introduction</h2>
            <p>
              Welcome to Abuzar's Portfolio. I am committed to protecting your privacy. This Privacy Policy explains how I collect, use, and protect your personal information.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mt-8 mb-4">2. Information Collection</h2>
            <p>
              I may collect information you provide directly through contact forms, including:
            </p>
            <ul className="list-disc list-inside space-y-2 ml-4">
              <li>Name</li>
              <li>Email address</li>
              <li>Subject and message content</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mt-8 mb-4">3. How We Use Information</h2>
            <p>
              The information you provide is used solely to:
            </p>
            <ul className="list-disc list-inside space-y-2 ml-4">
              <li>Respond to your inquiries</li>
              <li>Provide requested information or services</li>
              <li>Improve our portfolio and services</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mt-8 mb-4">4. Data Security</h2>
            <p>
              I implement appropriate technical and organizational measures to protect your personal information from unauthorized access, alteration, or disclosure.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mt-8 mb-4">5. Third-Party Services</h2>
            <p>
              This portfolio uses third-party services including:
            </p>
            <ul className="list-disc list-inside space-y-2 ml-4">
              <li>Vercel for hosting</li>
              <li>Analytics services for usage tracking</li>
              <li>Image services (Unsplash, etc.)</li>
            </ul>
            <p>
              These services have their own privacy policies, which I encourage you to review.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mt-8 mb-4">6. Cookies</h2>
            <p>
              This website may use cookies for analytics and user experience purposes. You can control cookie settings through your browser.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mt-8 mb-4">7. Your Rights</h2>
            <p>
              You have the right to:
            </p>
            <ul className="list-disc list-inside space-y-2 ml-4">
              <li>Access your personal information</li>
              <li>Request correction of inaccurate data</li>
              <li>Request deletion of your data</li>
              <li>Opt-out of communications</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mt-8 mb-4">8. Contact Us</h2>
            <p>
              If you have any questions about this Privacy Policy, please contact me at:
              <br />
              <span className="text-accent">khanabuzar7070@gmail.com</span>
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-white mt-8 mb-4">9. Changes to Privacy Policy</h2>
            <p>
              I may update this Privacy Policy from time to time. Changes will be posted on this page with an updated revision date.
            </p>
            <p className="text-dark-500 text-sm mt-4">
              Last updated: {new Date().toLocaleDateString()}
            </p>
          </section>
        </div>
      </motion.div>
    </main>
  );
}
